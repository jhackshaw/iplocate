module.exports =
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 752:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.build = void 0;
const fastify_1 = __importDefault(__webpack_require__(495));
const fastify_cors_1 = __importDefault(__webpack_require__(707));
const router_1 = __importDefault(__webpack_require__(873));
exports.build = (opts = {}) => {
    const app = fastify_1.default(opts);
    if (process.env.FRONTEND_DOMAIN) {
        app.register(fastify_cors_1.default, {
            origin: process.env.FRONTEND_DOMAIN,
        });
    }
    app.register(router_1.default);
    return app;
};


/***/ }),

/***/ 1:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(412), exports);


/***/ }),

/***/ 412:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ipLocate = void 0;
const db_1 = __webpack_require__(30);
const opts = {
    schema: {
        querystring: {
            required: ["ip"],
            type: "object",
            properties: {
                ip: {
                    anyOf: [
                        { type: "string", format: "ipv4" },
                        { type: "string", format: "ipv6" },
                    ],
                },
            },
        },
    },
    errorHandler: (error, _, reply) => {
        if (error.name === "AddressNotFoundError") {
            reply.status(404).send();
        }
        else {
            throw error;
        }
    },
};
const emptyToPartial = (obj) => obj;
exports.ipLocate = (fastify) => __awaiter(void 0, void 0, void 0, function* () {
    fastify.get("/search", opts, (request, reply) => {
        const { ip } = request.query;
        const reader = db_1.getReader();
        const cityInfo = reader.city(ip);
        reply.send(cityInfo);
    });
    fastify.get("/health", {}, (_, reply) => {
        const reader = db_1.getReader();
        const cityInfo = reader.city("8.8.8.8");
        const country = emptyToPartial(cityInfo.country);
        reply.status(country ? 200 : 500);
        reply.send();
    });
});


/***/ }),

/***/ 692:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getReader = void 0;
const geoip2_node_1 = __webpack_require__(980);
const fs_1 = __importDefault(__webpack_require__(747));
let reader = null;
exports.getReader = () => {
    if (reader) {
        return reader;
    }
    const dbBuffer = fs_1.default.readFileSync(process.env.GEOIP_DATABASE_PATH);
    reader = geoip2_node_1.Reader.openBuffer(dbBuffer);
    return reader;
};


/***/ }),

/***/ 30:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(692), exports);


/***/ }),

/***/ 916:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.handler = void 0;
const aws_serverless_express_1 = __importDefault(__webpack_require__(425));
const app_1 = __webpack_require__(752);
let server;
const serverFactory = (handler) => {
    server = aws_serverless_express_1.default.createServer(handler);
    return server;
};
const app = app_1.build({ serverFactory });
exports.handler = (event, context, cb) => {
    context.callbackWaitsForEmptyEventLoop = false;
    app.ready((e) => {
        if (e)
            return console.error(e.stack || e);
        aws_serverless_express_1.default.proxy(server, event, context, 'CALLBACK', cb);
    });
};


/***/ }),

/***/ 873:
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
const controller_1 = __webpack_require__(1);
function router(fastify) {
    return __awaiter(this, void 0, void 0, function* () {
        fastify.register(controller_1.ipLocate, { prefix: "/ip" });
    });
}
exports.default = router;


/***/ }),

/***/ 980:
/***/ ((module) => {

module.exports = require("@maxmind/geoip2-node");;

/***/ }),

/***/ 425:
/***/ ((module) => {

module.exports = require("aws-serverless-express");;

/***/ }),

/***/ 495:
/***/ ((module) => {

module.exports = require("fastify");;

/***/ }),

/***/ 707:
/***/ ((module) => {

module.exports = require("fastify-cors");;

/***/ }),

/***/ 747:
/***/ ((module) => {

module.exports = require("fs");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		if(__webpack_module_cache__[moduleId]) {
/******/ 			return __webpack_module_cache__[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	// module exports must be returned from runtime so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(916);
/******/ })()
;